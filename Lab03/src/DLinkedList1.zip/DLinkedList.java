public class DLinkedList<T> implements List<T> {
    private DNode head;
    private DNode tail;
    private DNode cursor;

    private class DNode {
        private final T element;
        private DNode next;
        private DNode prev;

        public DNode(T element) {
            this.element = element;
        }

        public T getElement() {
            return element;
        }

        public void setNext(DNode next) {
            this.next = next;
        }

        public DNode getNext() {
            return next;
        }

        public void setPrev(DNode prev) {
            this.prev = prev;
        }

        public DNode getPrev() {
            return prev;
        }
    } // d Class

    public DLinkedList() {
        head = new DNode(null);
        tail = new DNode(null);
        head.setNext(tail);
        tail.setPrev(head);
        head.prev = null;
        tail.next = null;
        cursor = null;
    } //Constructor

    @Override
    public void insert(T newElement) {
        if (newElement == null) {
            throw new IllegalArgumentException();
        }

        DNode newNode = new DNode(newElement);
        if (!isEmpty()) {
            cursor.getPrev().setNext(newNode);
            cursor.getNext().setPrev(newNode);
            newNode.setNext(cursor.getNext());
            newNode.setPrev(cursor.getPrev());

        } else {
            head.setNext(newNode);
            newNode.setPrev(head);
            newNode.setNext(tail);
            tail.setPrev(newNode);
        }
        cursor = newNode;
    }

    @Override
    public T remove() {
        T del = cursor.getElement();
        cursor.getNext().setPrev(cursor.getPrev());
        cursor.getPrev().setNext(cursor.getNext());
        cursor = cursor.getNext();
        return del;
    }

    @Override
    public T remove(T element) {
        T del = null;
        DNode localCursor = head;
        while (localCursor.element != null) {
            if (localCursor.element == element) {
                cursor = localCursor;
                del = remove();
            }
            localCursor = localCursor.getNext();
        }
        return del;
    }

    @Override
    public void clear() {
        head.setNext(tail);
        tail.setPrev(head);
    }

    @Override
    public void replace(T newElement) {
        if (!isEmpty() && newElement != null) {
            remove();
            insert(newElement);
        }
    }

    @Override
    public boolean isEmpty() {
        return head.getNext() == tail && tail.getPrev() == head;
    }

    @Override
    public boolean goToBeginning() {
        if (!isEmpty()) {
            cursor = head.getNext();
            return true;
        }
        return false;
    }

    @Override
    public boolean goToEnd() {
        if (!isEmpty()) {
            cursor = tail.prev;
            return true;
        }
        return false;
    }

    @Override
    public T getNext() {
        if (cursor.next != null && cursor.next != tail) {
            cursor = cursor.next;
            return cursor.element;
        }
        return null;
    }

    @Override
    public T getPrev() {
        if (cursor.prev != null && cursor.prev != head) {
            cursor = cursor.prev;
            return cursor.element;
        }
        return null;
    }

    @Override
    public T getCursor() {
        if (!isEmpty()) {
            return cursor.element;
        }
        return null;
    }

    @Override
    public boolean hasNext() {
        if (isEmpty()) return false;
        return cursor.next != null && cursor.next != tail;
    }

    @Override
    public boolean hasPrev() {
        if (isEmpty()) return false;
        return cursor.prev != null && cursor.prev != head;
    }

}
