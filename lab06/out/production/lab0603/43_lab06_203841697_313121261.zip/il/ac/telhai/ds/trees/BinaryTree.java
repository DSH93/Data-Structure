package il.ac.telhai.ds.trees;

public class BinaryTree<T> implements BinaryTreeI<T> {


    private BinaryTreeI<T> right;
    private BinaryTreeI<T> left;
    private T key;

    public BinaryTree(T root) {
        this.key = root;
        this.right = null;
        this.left = null;
    }

    public BinaryTree(T root, BinaryTreeI<T> right, BinaryTreeI<T> left) {
        this.key = root;
        this.right = right;
        this.left = left;
    }

    public BinaryTree() {
        this.key = null;
        this.right = null;
        this.left = null;

    }

    @Override
    public BinaryTreeI<T> getLeft() {
        return this.left;
    }

    @Override
    public BinaryTreeI<T> getRight() {
        return this.right;

    }

    @Override
    public T getValue() {
        return this.key;
    }

    @Override
    public void setValue(T value) {
        this.key = value;
    }

    @Override
    public void setLeft(BinaryTreeI<T> left) {
        this.left = (BinaryTree) left;
    }

    @Override
    public void setRight(BinaryTreeI<T> right) {
        this.right = (BinaryTree) right;
    }

    @Override
    public boolean isLeaf() {
        return this.right == null && this.left == null;
    }

    @Override
    public int height() {
        if (isLeaf()) return 0;
        if (getRight() == null) return 1 + getLeft().height();
        if (getLeft() == null) return 1 + getRight().height();

        return 1 + Math.max(getLeft().height(), getRight().height());
    }

    @Override
    public int size() {
        if (isLeaf()) return 1;
        if (getLeft() == null) return 1 + getLeft().size();
        if (getLeft() == null) return 1 + getRight().size();
        return 1 + getLeft().height() + getRight().height();
    }

    @Override
    public void clear() {
        this.right = null;
        this.left = null;

    }

    @Override
    public String preOrder() {
        return preOrder(" ", " ");
    }

    @Override
    public String preOrder(String separationBeforeVal, String separationAfterVal) {

        StringBuilder s = new StringBuilder();
        s.append(separationBeforeVal).append(key.toString()).append(separationAfterVal);

        if (left != null) {
            s.append(left.preOrder(separationBeforeVal, separationAfterVal));
        }
        if (right != null) {
            s.append(right.preOrder(separationBeforeVal, separationAfterVal));
        }
        return s.toString();
    }

    @Override
    public String inOrder() {
        return inOrder(" ", " ");
    }

    @Override
    public String inOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder res = new StringBuilder();
        if (isLeaf()) return separationBeforeVal + key.toString() + separationAfterVal;
        if (left != null) res.append(left.inOrder(separationBeforeVal, separationAfterVal));
        res.append(separationBeforeVal).append(key.toString()).append(separationAfterVal);

        if (right != null) res.append(right.inOrder(separationBeforeVal, separationAfterVal));

        return res.toString();
    }


    @Override
    public String postOrder() {
        return postOrder(" ", " ");
    }

    @Override
    public String postOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder res = new StringBuilder();
        if (right != null) res.append(right.postOrder(separationBeforeVal, separationAfterVal));
        if (left != null) res.append(left.postOrder(separationBeforeVal, separationAfterVal));
        res.append(separationBeforeVal).append(key.toString()).append(separationAfterVal);
        return res.toString();
    }
}
