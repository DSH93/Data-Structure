import static org.junit.Assert.assertEquals;

public class TestMat  {
    public static void main(String[] args) {
        SparseMatrix mat = new SparseMatrix<>(3,1);
        mat.toString();

    }
}
