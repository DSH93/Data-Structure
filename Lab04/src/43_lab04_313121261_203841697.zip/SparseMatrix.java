public class SparseMatrix<T> implements Matrix<T> {

    private final DLinkedList<SparseMatrixEntry> Mat;
    private int size;
    private T domVal;
    private boolean isTranspose = false;


    private class SparseMatrixEntry {
        private T value;
        private int row;
        private int col;


        public SparseMatrixEntry(int row, int col, T val) {
            this.col = col;
            this.row = row;
            this.value = val;
        }
        public int getRow() {
            return row;
        }

        public void setRow(int row) {
            this.row = row;
        }

        public int getCol() {
            return col;
        }

        public void setCol(int col) {
            this.col = col;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T newVal) {
            this.value = newVal;
        }

    }

    public SparseMatrix(T defaultValue) {
        Mat = new DLinkedList<>();
        size = MAX_SIZE;
        domVal = defaultValue;
    }

    public SparseMatrix(int size, T defaultValue) {
        Mat = new DLinkedList<SparseMatrixEntry>();
//        for(int i=0; i<size; i++){
//            for (int j=0; j<size; j++){
//                Mat.insert(new SparseMatrixEntry(i,j,defaultValue));
//            }
//        }
        this.size = size;
        this.domVal = defaultValue;
    }

    @Override
    public T get(int row, int col) {
        if (row > size || col > size || col < 1 || row < 1) throw new IllegalArgumentException();;
        if (isTranspose) {
            int tmp = col;
            col = row;
            row = tmp;
        }
        Mat.goToBeginning();
        if (Mat.isEmpty()) return domVal;
        boolean endListFlag = true;
        while (endListFlag) {
            if (Mat.getCursor().row == row && Mat.getCursor().col == col) {
                return Mat.getCursor().value;
            }
            if (endListFlag = Mat.hasNext()) {
                Mat.getNext();
            }
        }
        return domVal;
    }

    @Override
    public void set(int row, int col, T element) {
        if (row > size || col > size || col < 1 || row < 1) throw new IllegalArgumentException(); ;
//        if (isTranspose) {
//            int tmp = col;
//            col = row;
//            row = tmp;
//        }
        Mat.goToBeginning();
        boolean endListFlag = true;
        while (endListFlag && !Mat.isEmpty()) {
            if (Mat.getCursor().row == row && Mat.getCursor().col == col) {
                Mat.getCursor().value = element;
                return;
            }
            if (endListFlag = Mat.hasNext()) {
                Mat.getNext();
            }        }
        Mat.insert(new SparseMatrixEntry(row,col,element));
    }

    @Override
    public void transpose() {
        if (!isTranspose) isTranspose = true;
        else isTranspose = false;
    }

//    @Override
//    public Matrix<T> getTranspose() {
//        SparseMatrix mt = new SparseMatrix(size,domVal);
//        mt.transpose();
//        return mt;
//    }

}
